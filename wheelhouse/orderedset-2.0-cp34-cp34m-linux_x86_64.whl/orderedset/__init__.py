# encoding: utf-8
__version__ = '2.0'


from ._orderedset import OrderedSet
