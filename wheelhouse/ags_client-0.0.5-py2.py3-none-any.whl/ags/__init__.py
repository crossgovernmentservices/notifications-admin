# -*- coding: utf-8 -*-
"""
A Python client library for Accessing GaaP Services.
"""

from ags.client import Client


__version__ = '0.0.5'
