# -*- coding: utf-8 -*-


class AuthenticationRequestError(Exception):
    pass


class BrokerConfigError(Exception):
    pass
