def test_for_testing_sake():
    assert 1 == 1
